// Your other functions and event handlers

// Example function for redirecting to an edit profile page
function editProfile() {
  // Displaying an alert to indicate the action
  alert("Redirecting to profile edit page...");

  // Redirect the user to the edit-profile page
  window.location.href = "edit-profile.html"; // Link to a page where users can edit their profile
}

// You can call this function when the user clicks the "Edit Profile" button
