document.addEventListener("DOMContentLoaded", () => {
  const postForm = document.getElementById("post-form");
  const postContent = document.getElementById("post-content");
  const postsContainer = document.getElementById("posts-container");

  // Load posts from the backend when the page loads
  loadPosts();

  // Handle form submission
  postForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const content = postContent.value.trim();
    if (content === "") return;

    const post = { content };

    try {
      const response = await fetch("/api/posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(post),
      });

      if (response.ok) {
        postContent.value = ""; // Clear input
        loadPosts(); // Reload posts
      }
    } catch (error) {
      console.error("Error posting:", error);
    }
  });

  // Fetch posts from the backend
  async function loadPosts() {
    try {
      const response = await fetch("/api/posts");
      const posts = await response.json();

      postsContainer.innerHTML = ""; // Clear the container

      posts.forEach((post) => {
        const postElement = document.createElement("div");
        postElement.classList.add("post");
        postElement.innerHTML = `
          <p>${post.content}</p>
          <small>${new Date(post.timestamp).toLocaleString()}</small>
          <button class="delete-btn" data-id="${post.id}">Delete</button>
        `;
        postsContainer.appendChild(postElement);
      });

      // Attach delete event listeners
      document.querySelectorAll(".delete-btn").forEach((button) => {
        button.addEventListener("click", async (event) => {
          const postId = event.target.getAttribute("data-id");
          await deletePost(postId);
        });
      });
    } catch (error) {
      console.error("Error loading posts:", error);
    }
  }

  // Delete a post
  async function deletePost(id) {
    try {
      const response = await fetch(`/api/posts/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        loadPosts();
      }
    } catch (error) {
      console.error("Error deleting post:", error);
    }
  }
});
